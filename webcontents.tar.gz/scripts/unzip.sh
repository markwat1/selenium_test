#!/bin/bash
cd /home/ec2-user
unzip -o -d /usr/share/nginx/ artifact.zip
